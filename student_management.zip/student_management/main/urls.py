from django.urls import path
from . import views

app_name = 'main'

urlpatterns = [
    path('', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('guest-dashboard/', views.guest_dashboard, name='guest_dashboard'),
    path('guest-login/', views.guest_login, name='guest_login'),
    path('schedule/', views.schedule, name='schedule'),
    path('schedule/create/', views.create_schedule_event, name='create_schedule_event'),
    path('schedule/<int:event_id>/delete/', views.delete_schedule_event, name='delete_schedule_event'),
    path('schedule/check_availability/', views.check_availability, name='check_availability'),
    path('tasks/', views.tasks_view, name='tasks'),
    path('tasks/create/', views.create_task, name='create_task'),
    path('tasks/<int:task_id>/update/', views.update_task_status, name='update_task_status'),
    path('tasks/<int:task_id>/delete/', views.delete_task, name='delete_task'),
    path('users/', views.users, name='users'),
    path('user/<int:user_id>/', views.user_profile, name='user_profile'),
    path('about/', views.about, name='about'),
]