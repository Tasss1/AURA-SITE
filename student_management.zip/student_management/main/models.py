from django.db import models
from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.utils.translation import gettext_lazy as _


class UserManager(BaseUserManager):
    def create_user(self, username, email, password=None, **extra_fields):
        if not email:
            raise ValueError(_('Users must have an email address'))
        email = self.normalize_email(email)
        user = self.model(username=username, email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, username, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError(_('Superuser must have is_staff=True.'))
        if extra_fields.get('is_superuser') is not True:
            raise ValueError(_('Superuser must have is_superuser=True.'))

        return self.create_user(username, email, password, **extra_fields)


class User(AbstractUser):
    email = models.EmailField(_('email address'), unique=True)

    objects = UserManager()

    class Meta:
        db_table = 'custom_user'
        verbose_name = _('Пользователь')
        verbose_name_plural = _('Пользователи')
        ordering = ['username']

    def __str__(self):
        return self.username


class Project(models.Model):
    name = models.CharField(
        max_length=100,
        verbose_name=_('Название'),
        help_text=_('Введите название проекта')
    )
    description = models.TextField(
        verbose_name=_('Описание'),
        help_text=_('Опишите проект'),
        blank=True
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name=_('Дата создания')
    )
    members = models.ManyToManyField(
        User,
        related_name='projects',
        verbose_name=_('Участники'),
        blank=True
    )

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = _('Проект')
        verbose_name_plural = _('Проекты')
        ordering = ['-created_at']


class Task(models.Model):
    class Status(models.TextChoices):
        TODO = 'To Do', _('К выполнению')
        IN_PROGRESS = 'In Progress', _('В процессе')
        DONE = 'Done', _('Выполнено')

    title = models.CharField(
        max_length=200,
        verbose_name=_('Название'),
        help_text=_('Введите название задачи')
    )
    description = models.TextField(
        verbose_name=_('Описание'),
        help_text=_('Опишите задачу'),
        blank=True
    )
    developer = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='tasks',
        verbose_name=_('Исполнитель')
    )
    project = models.ForeignKey(
        Project,
        on_delete=models.CASCADE,
        related_name='tasks',
        verbose_name=_('Проект')
    )
    deadline = models.DateTimeField(
        verbose_name=_('Срок выполнения')
    )
    status = models.CharField(
        max_length=20,
        choices=Status.choices,
        default=Status.TODO,
        verbose_name=_('Статус')
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name=_('Дата создания')
    )

    def __str__(self):
        return f"{self.title} ({self.get_status_display()})"

    class Meta:
        verbose_name = _('Задача')
        verbose_name_plural = _('Задачи')
        ordering = ['-deadline']
        indexes = [
            models.Index(fields=['status']),
            models.Index(fields=['deadline']),
        ]


class Schedule(models.Model):
    title = models.CharField(
        max_length=200,
        verbose_name=_('Название'),
        help_text=_('Введите название события')
    )
    description = models.TextField(
        verbose_name=_('Описание'),
        blank=True,
        help_text=_('Опишите событие')
    )
    start_time = models.DateTimeField(
        verbose_name=_('Время начала')
    )
    end_time = models.DateTimeField(
        verbose_name=_('Время окончания')
    )
    creator = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='created_events',
        verbose_name=_('Организатор')
    )
    participants = models.ManyToManyField(
        User,
        related_name='events',
        verbose_name=_('Участники'),
        blank=True
    )
    created_at = models.DateTimeField(
        auto_now_add=True,
        verbose_name=_('Дата создания')
    )

    def __str__(self):
        return f"{self.title} ({self.start_time:%d.%m.%Y %H:%M} - {self.end_time:%H:%M})"

    class Meta:
        verbose_name = _('Событие')
        verbose_name_plural = _('События')
        ordering = ['-start_time']
        indexes = [
            models.Index(fields=['start_time']),
            models.Index(fields=['end_time']),
        ]