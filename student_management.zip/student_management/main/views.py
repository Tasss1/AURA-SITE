from django.utils import timezone
from datetime import timedelta, datetime
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.db.models import Q, Exists, OuterRef, Count
from django.views.decorators.csrf import csrf_protect
import json
from .models import Task, Project, Schedule, User
from .forms import LoginForm


@csrf_protect
def login_view(request):
    if request.method == 'POST':
        form = LoginForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            if user.username == 'guest_user':
                return redirect('main:guest_dashboard')
            return redirect('main:dashboard')
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form})


def guest_login(request):
    # Создаем или получаем гостевого пользователя
    guest_user, created = User.objects.get_or_create(
        username='guest_user',
        defaults={
            'first_name': 'Гость',
            'last_name': 'Aura',
            'email': '',
            'is_active': True,
            'is_staff': False,
            'is_superuser': False
        }
    )

    if created:
        guest_user.set_unusable_password()
        guest_user.save()

        # Создаем демонстрационные данные для гостя
        demo_project = Project.objects.create(
            name="Демо проект",
            description="Это демонстрационный проект для гостевого пользователя"
        )

        # Создаем демонстрационные задачи
        Task.objects.create(
            title="Пример задачи в работе",
            description="Это пример задачи, которая находится в статусе 'В работе'",
            developer=guest_user,
            project=demo_project,
            deadline=timezone.now() + timedelta(days=3),
            status='In Progress'
        )

        Task.objects.create(
            title="Пример завершенной задачи",
            description="Это пример завершенной задачи",
            developer=guest_user,
            project=demo_project,
            deadline=timezone.now() - timedelta(days=1),
            status='Done'
        )

        Task.objects.create(
            title="Задача на сегодня",
            description="Необходимо выполнить эту задачу сегодня",
            developer=guest_user,
            project=demo_project,
            deadline=timezone.now(),
            status='To Do'
        )

        # Создаем демонстрационные события в расписании
        Schedule.objects.create(
            title="Еженедельная встреча",
            description="Планирование на неделю",
            start_time=timezone.now() + timedelta(hours=2),
            end_time=timezone.now() + timedelta(hours=3),
            creator=guest_user
        ).participants.add(guest_user)

        Schedule.objects.create(
            title="Обзор задач",
            description="Обсуждение текущих задач",
            start_time=timezone.now() + timedelta(days=1, hours=10),
            end_time=timezone.now() + timedelta(days=1, hours=11),
            creator=guest_user
        ).participants.add(guest_user)

    # Авторизуем гостя
    user = authenticate(username='guest_user', password=None)
    if user is not None:
        login(request, user)
        return redirect('main:guest_dashboard')

    return redirect('main:login')


@login_required
def guest_dashboard(request):
    if request.user.username != 'guest_user':
        return redirect('main:dashboard')

    # Получаем данные для гостевой панели
    tasks = Task.objects.filter(developer=request.user).order_by('-deadline')[:5]
    schedule_events = Schedule.objects.filter(
        Q(participants=request.user) | Q(creator=request.user)
    ).distinct().order_by('start_time')[:5]

    return render(request, 'main/guest_dashboard.html', {
        'tasks': tasks,
        'schedule_events': schedule_events
    })

# Остальные представления остаются без изменений
# ...

@login_required
def logout_view(request):
    logout(request)
    return redirect('main:login')


@login_required
def dashboard(request):
    if request.user.username == 'guest_user':
        return redirect('main:guest_dashboard')

    now = timezone.now()

    # Получаем статистику по задачам
    tasks = Task.objects.filter(developer=request.user)

    total_tasks = tasks.count()
    in_progress_tasks = tasks.filter(status__in=['To Do', 'In Progress']).count()
    completed_tasks = tasks.filter(status='Done').count()
    overdue_tasks = tasks.filter(deadline__lt=now, status__in=['To Do', 'In Progress']).count()

    # Ближайшие задачи
    current_tasks = tasks.filter(
        status__in=['To Do', 'In Progress']
    ).order_by('deadline')[:5]

    # Данные для графика продуктивности
    productivity_data = [0] * 7
    tasks_per_day = (
        tasks.filter(created_at__gte=now - timedelta(days=7))
        .extra({'day': "date(created_at)"})
        .values('day')
        .annotate(count=Count('id'))
        .order_by('day')
    )

    for item in tasks_per_day:
        day_index = (item['day'].weekday() + 1) % 7
        productivity_data[day_index] = item['count']

    return render(request, 'main/dashboard.html', {
        'current_tasks': current_tasks,
        'total_tasks': total_tasks,
        'in_progress_tasks': in_progress_tasks,
        'completed_tasks': completed_tasks,
        'overdue_tasks': overdue_tasks,
        'productivity_data': productivity_data,
    })


@login_required
def guest_dashboard(request):
    if request.user.username != 'guest_user':
        return redirect('main:dashboard')

    # Получаем данные для гостевой панели
    tasks = Task.objects.filter(developer=request.user).order_by('-deadline')[:5]
    schedule_events = Schedule.objects.filter(
        Q(participants=request.user) | Q(creator=request.user)
    ).distinct().order_by('start_time')[:5]

    return render(request, 'main/guest_dashboard.html', {
        'tasks': tasks,
        'schedule_events': schedule_events
    })


@login_required
def schedule(request):
    if request.user.username == 'guest_user':
        return redirect('main:guest_dashboard')

    now = timezone.now()
    schedules = Schedule.objects.filter(
        Q(participants=request.user) | Q(creator=request.user)
    ).distinct().order_by('start_time')

    hours = range(8, 20)
    week_start = now - timedelta(days=now.weekday())
    week_days = []

    for i in range(7):
        day = week_start + timedelta(days=i)
        events = schedules.filter(start_time__date=day.date())
        week_days.append({
            'name': day.strftime('%A'),
            'date': day,
            'events': events
        })

    return render(request, 'main/schedule.html', {
        'schedules': schedules,
        'current_date': now,
        'hours': hours,
        'week_days': week_days,
        'available_users': User.objects.exclude(id=request.user.id)
    })


@login_required
@require_http_methods(["POST"])
def create_schedule_event(request):
    try:
        data = json.loads(request.body)
        start_time = datetime.fromisoformat(data['start_time'])
        end_time = datetime.fromisoformat(data['end_time'])

        overlapping_events = Schedule.objects.filter(
            Q(participants__in=data['participants']) | Q(creator=request.user),
            start_time__lt=end_time,
            end_time__gt=start_time
        ).exists()

        if overlapping_events:
            return JsonResponse({
                'success': False,
                'error': 'У некоторых участников уже есть события в это время'
            })

        event = Schedule.objects.create(
            title=data['title'],
            description=data.get('description', ''),
            start_time=start_time,
            end_time=end_time,
            creator=request.user
        )
        event.participants.set(data['participants'])

        return JsonResponse({
            'success': True,
            'event': {
                'id': event.id,
                'title': event.title,
                'start': event.start_time.isoformat(),
                'end': event.end_time.isoformat()
            }
        })
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
@require_http_methods(["DELETE"])
def delete_schedule_event(request, event_id):
    try:
        event = Schedule.objects.get(id=event_id, creator=request.user)
        event.delete()
        return JsonResponse({'success': True})
    except Schedule.DoesNotExist:
        return JsonResponse({'success': False, 'error': 'Событие не найдено'})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
def check_availability(request):
    try:
        start_time = request.GET.get('start_time')
        end_time = request.GET.get('end_time')

        users = User.objects.annotate(
            is_available=~Exists(
                Schedule.objects.filter(
                    participants=OuterRef('pk'),
                    start_time__lt=end_time,
                    end_time__gt=start_time
                )
            )
        ).values('id', 'username', 'is_available')

        return JsonResponse({
            'success': True,
            'users': list(users)
        })
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
def tasks_view(request):
    if request.user.username == 'guest_user':
        return redirect('main:guest_dashboard')

    tasks = Task.objects.filter(developer=request.user).select_related('project')
    projects = Project.objects.all()

    return render(request, 'main/tasks.html', {
        'tasks': tasks,
        'projects': projects
    })


@login_required
def create_task(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            task = Task.objects.create(
                title=data['title'],
                description=data.get('description', ''),
                developer=request.user,
                project_id=data['project'],
                deadline=data['deadline'],
                status='To Do'
            )
            return JsonResponse({
                'success': True,
                'task': {
                    'id': task.id,
                    'title': task.title,
                    'deadline': task.deadline.strftime('%Y-%m-%d'),
                    'status': task.status
                }
            })
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    return JsonResponse({'success': False, 'error': 'Неверный метод запроса'})


@login_required
def update_task_status(request, task_id):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            task = Task.objects.get(id=task_id, developer=request.user)
            task.status = data['status']
            task.save()
            return JsonResponse({'success': True})
        except Task.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Задача не найдена'})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    return JsonResponse({'success': False, 'error': 'Неверный метод запроса'})


@login_required
def delete_task(request, task_id):
    try:
        task = Task.objects.get(id=task_id, developer=request.user)
        task.delete()
        return JsonResponse({'success': True})
    except Task.DoesNotExist:
        return JsonResponse({'success': False, 'error': 'Задача не найдена'})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
def user_profile(request, user_id):
    user = get_object_or_404(User, id=user_id)

    # Получаем статистику для профиля
    tasks = Task.objects.filter(developer=user)
    completed_tasks = tasks.filter(status='Done').count()
    active_tasks = tasks.exclude(status='Done').count()
    events_count = Schedule.objects.filter(participants=user).count()

    return render(request, 'main/user_profile.html', {
        'profile_user': user,
        'completed_tasks': completed_tasks,
        'active_tasks': active_tasks,
        'events_count': events_count
    })


@login_required
def users(request):
    if request.user.username == 'guest_user':
        return redirect('main:guest_dashboard')

    users = User.objects.exclude(id=request.user.id)
    return render(request, 'main/users.html', {'users': users})


def about(request):
    return render(request, 'main/about.html')